name = (input("Enter your name"))
costofappliance = float(input("enter cost of appliance"))

if costofappliance > 1000:
  warranty = 0.10
else:
  warranty = 0.05

costofwarranty = costofappliance * warranty

totalcost = costofappliance * warranty

print("name", name)
print("Cost of appliance", costofappliance)
print("Cost of Warranty", costofwarranty)
print("Total", totalcost)