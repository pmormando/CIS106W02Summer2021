PaoCD = int(input("Enter Principle amount of CD"))
YtoM = input("Enter Years to Maturity")

if PaoCD > 100000:
 YtoM = 5
 Interestrate = 0.06
elif PaoCD > 50000 and PaoCD < 100000:
  YtoM = 10
  Interestrate = 0.05
elif PaoCD > 50000 and PaoCD < 100000:
   YtoM = 5
   Interestrate = 0.04
else:
   Interestrate = 0.02

PaoCD = PaoCD
firstyearinterest = PaoCD * Interestrate
Interestrate * Interestrate

print("Principle Amount of CD", PaoCD)
print("First Year Interest", firstyearinterest)
print("Interestrate", Interestrate)