def display(scoresArray):
  #For finding highest value
  high_var = 0                       #initialize a variable to high_var to 0
  for i in range(len(scoresArray)):
      if scoresArray[i] > high_var:   #If the array value is higher than the high_var
          high_var = scoresArray[i]   #then set high_var to the array value
          high_index = i                #set high_index to the position of the array
 
  #For finding lowest value
  low_var = 999
  for i in range(len(scoresArray)):   #initialize a variable to low_var to 999
      if scoresArray[i] < low_var:       #If the array value is lower than the low_var
          low_var = scoresArray[i]       #then set low_var to the array value
          low_index = i                #set low_index to the position of the array
 
 
  sum_var = 0
  for i in range(len(scoresArray)):   #sum all the test scores as you proceed through the loop
      sum_var = sum_var + scoresArray[i]
 
  avg_var = sum_var/len(scoresArray)    #compute average using sum_var
 
  print("Your Last Name")
  print("Scores Array = ", scoresArray)
  print("Highest value = ", high_var)
  print("Lowest value = ", low_var)
  print("Average value = ", avg_var)
 
#Testing the function
scoresArray = [98, 13, 55, 89, 12, 88, 93, 57, 73]
display(scoresArray)
