amountofmeal = float(input("enter amount of meal"))

tip = amountofmeal * 0.15

print("tip is", tip)