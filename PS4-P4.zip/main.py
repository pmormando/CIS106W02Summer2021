done = False 
while not done:
    print("Y - Start Program")
    print("N - Quit")
    choice = input("Which do you choose? :")
    if choice == "y":
      finished = False
      empnum = 0
      totalpay = 0
      while not finished:
        last = input("What is your last name?")
        hours = float(input("How many hours did you work?"))
        rtpay = float(input("What is your hourly wage?"))
        if hours > 40:
          othours = hours - 40
          hours = 40
        else:
          hours = hours
          othours = 0
        netpay = (hours * rtpay) + (othours * (1.5 * rtpay))
        print("Last name: ", last)
        print("Gross pay: $", netpay)
        empnum = empnum + 1
        totalpay = totalpay + netpay
        error = False
        while not error:
          print("Y - Continue")
          print("N - Quit")
          exit = input("Which do oyu choose?")
          if exit == "Y":
           break
          elif exit == "N":
           done = True
           finished = True
           break
          else:
            print("Invalid Choice")
      else:
        done = True
    elif choice == "N":
        print("Existing Program!")
        done = True
    else:
      print("Invalid Choice")
else:
  print("Total Pay: $", totalpay)
  print("Total Number of Employees: ", empnum)
  print("Goodbye!")