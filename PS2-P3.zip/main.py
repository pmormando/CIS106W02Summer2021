NoB = float(input("enter number of books being purchased"))
CPB = float(input("enter cost per book"))

order = NoB * CPB

if order > 50.00:
  shipping = 0
else:
  shipping = 25.00

TTO = order + shipping
shipping = shipping

print("Order total", TTO)
print("shipping cost", shipping)