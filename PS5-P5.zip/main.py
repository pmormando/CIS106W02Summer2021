def compbattingavg(hits, atbats):
  battingavg = hits / atbats

  return battingavg

lastname = input("last name")
hits = float(input("enter hits"))
atbats = float(input("enter number of at bats"))

battingavg = compbattingavg(hits, atbats)

print("last name", lastname)
print("batting average", battingavg)