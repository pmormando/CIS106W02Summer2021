# compute tax and total
amountofitem= float(input("Enter amount of the item"))

# process phase

tax= amountofitem * 0.07
total= tax + amountofitem

#output phase
print ("Amount entered: $", amountofitem)
print ("tax is:         $", tax)
print ("Total Order:    $", total)

