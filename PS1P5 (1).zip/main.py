#comment my program to do arthimetic
#n1 = 12
#n2 = 10

n1 = float(input("Enter a Number"))
n2 = float(input("Enter another Number"))

s= n1 + n2
p= n1 * n2
d= n1 - n2

print("sum is", s)
print("difference is", d)
print("Product is", p)