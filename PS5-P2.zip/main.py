for c in range (1, 6, 1):
  print(c)
  for count in range (1, 11, 1):
    print (count)