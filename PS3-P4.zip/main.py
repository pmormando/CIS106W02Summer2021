NoOCT = int(input("Enter Number of Concert Tickets"))

if NoOCT>= 25:
  PPT = 50
elif NoOCT >= 10 and NoOCT <= 24:
  PPT = 60
elif NoOCT >= 5 and NoOCT <= 9:
  PPT = 70
else:
  PPT = 75

totalcost = NoOCT * PPT

print("Number of Concert Tickets", NoOCT)
print("Price per Ticket", PPT)
print("Total Cost", totalcost)