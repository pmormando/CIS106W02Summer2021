def display(names,scores):
 #use the indexing
 for i in range(len(names)):
   print(names[i]," ",scores[i])
 
names=["name1","name2","name3","name4","name5","name6","name7","name8","name9","name10"]
scores=[78,76,54,67,98,65,87,98,93,82]
display(names,scores)
