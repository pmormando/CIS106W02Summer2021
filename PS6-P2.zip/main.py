def function(avj, totalpoints):
  avjscore = (exam1 + exam2 + exam3) / 3
  totalpoints = exam1 + exam2 + exam3

  return totalpoints, avjscore

studentslastname = input("students last name")
exam1 = float(input("exam score one"))
exam2 = float(input("exam score two"))
exam3 = float(input("exam score three"))

totalpoints , avjscore = function(avjscore, totalpoints)

print(studentslastname)
print("total points", totalpoints)
print("average score", avjscore)