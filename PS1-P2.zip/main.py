lastname = (input("enter a name"))

ex1= float(input("enter a number"))
ex2= float(input("enter another number"))

avgs = (ex1 +ex2)/2
ln = lastname

print("lastname is", ln)
print("avgscore is", avgs)