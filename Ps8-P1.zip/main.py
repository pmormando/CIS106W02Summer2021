#Employee_Bonus class
class Employee_Bonus:
   #constructor
   def __init__(self,salary,rate):
       #to this class
       self.salary=salary
       self.rate=rate
      
   #method calculate_bonus
   def calculate_bonus(self):
       #return bonus
       return self.salary*self.rate
      
      
#student class
class Student:
   #constructor
   def __init__(self,first_name,last_name,district_code,enrolled_credits):
       #to this class assigning
       self.first_name=first_name
       self.last_name=last_name
       self.district_code=district_code
       self.enrolled_credits=enrolled_credits
       #pass
       pass
   #tution owned method
   def tution_owned(self):
       #if condition
       if self.district_code=="I":
           #assigning tution
           tut=250.00
       #else condition
       else:
           #assigning tution
           tut=500.00
       #return tut
       return tut
#employee object
e1=Employee_Bonus(500,4)
#printing Employee_Bonus
print("The employee bonus is",e1.calculate_bonus())
#print new line
print()
 
 
#creating student object
s1=Student("John","Brown","I",20)
#printing
print("First Name is:",s1.first_name)
print("Last Name is:",s1.last_name)
print("The tution owned is:",s1.tution_owned())
