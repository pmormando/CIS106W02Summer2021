done = False
totaldiscount = 0
asknum = 0
while not done:
  while asknum < 1:
    choice = input("Would you like to run this program? (Y/N) ")
    asknum = asknum + 1
  if choice == "Y":
    quant = float(input("Quantity: "))
    price = float(input("Price: $"))
    extprice = quant * price
    finalprice = extprice
    if extprice > 10000.00:
      finalprice = extprice * 0.75
      discount = extprice * 0.25
    else:
      finalprice = extprice * 0.9
      discount = extprice * 0.1
    totaldiscount = totaldiscount + discount
    print("Extended Price: $", extprice)
    print("Discount Amount: $", discount)
    print("Total: $", finalprice)
    print(" ")
    leave = False
    while not leave:
      again = input("Would you like to enter another item? (Y/N)")
      if again == "Y":
        break
      elif again == "N":
        done = True
        leave = True
      else:
        print("Not a valid input")
  elif choice == "N":
    done = True
  else:
    print("Not a valid input")
  while done:
    print("Your total discount was: $", totaldiscount)
    print("Thank you! Have a great day!")
    done = False