def payrate(L, A, J):
  L = 25
  A = 30
  J = 50

  return payrate

lastname = input("enter last name")
jobcode = input("enter job code (L, A, or J) ")
hoursworked = float(input("enter amount of hours worked"))

def grosspay(hoursworked, payrate):
  if hoursworked > 40:
    grosspay = (hoursworked * payrate) + (hoursworked / 2) * payrate
  else:
      grosspay = hoursworked * payrate

  return grosspay

grosspay = grosspay

print(lastname)
print(grosspay)