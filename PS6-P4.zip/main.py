def comput(avjscore, handicap):
  avjscore = (gs1 + gs2 + gs3) / 3
  avjscorewithhandicap = avjscore + handicap

  return avjscore, handicap

bln = input("bowlers last name")
gs1 = float(input("game score one"))
gs2 = float(input("game score two"))
gs3 = float(input("game score three"))
handicap = float(input("enter handicap"))

avjscore,handicap = comput(avjscore,handicap)

print(bln)
print("average score", avgscore)
print("average score with handicap", avjscorewithhandicap)