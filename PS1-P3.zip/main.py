gallonsused = float(input("enter gallons used"))
milestravelled = float(input("enter miels travelled"))

mpg= gallonsused / milestravelled

print("mpg is", mpg)