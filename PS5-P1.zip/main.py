p = float(input("enter principle amount"))
t = int(input("enter term in years"))
r = float(input("enter interest rate in decimal form"))

for y in range (1, t+1, 1):
  i = p + r
  nb = i + p
  print ("year: ", y)
  print("starting amount: ", p)
  print("interest earned: ", i)
  print("end of year balance", nb)
  p = nb