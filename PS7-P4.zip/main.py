#Prompt the user for a number which will represent the number of items in a list
n = int(input("Enter number of items: "))
first = []
#use a for loop to add that many integers to the list
for i in range(0,n):
 first.append(int(input()))
print(first)
#Insert the score of 99 at position 1 within the list.
first.insert(1,99)
print(first)
#Replace the value of 99 with the value 100
for i in range(0,len(first)):
 if first[i] == 99:
   first[i] = 100
print(first)
#Create a second list
second=[500, 600, 700, 800, 900]
print(second)
#Extend the first list with this second list
first.extend(second)
print(first)
#Remove the value 800 from the first list.
first.remove(800)
print(first)
#Remove the third item from the first list
first.pop(2)
#Create a list of grades
grades = ["A", "B", "C", "A", "A", "C"]
#Display a count of the number of A grades
print(grades.count("A"))
#Display the index (position) of the first B grade.
print(grades.index("B"))
#Look for grade of F in the grades list
if "F" not in grades:
 print("F is not in the list")
#Clear (but do not delete) the second list of integers
second.clear()
print(second)
#Delete the second list
del second
#should get an error because the list no longer exists
print(second)
 
#Create a list of players
players = ["Rizzo", "Hayword", "Shawrber", "Happ", "Bryan"]
#Sort the list of players
players.sort()
print(players)
#Make a copy of the list of players called players2
players2 = players
print(players2)
#Reverse the order of players2.
players2 = sorted(players2, reverse=True)
print(players)
print(players2)

