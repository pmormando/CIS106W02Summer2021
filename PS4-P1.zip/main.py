startv = 1
stopv = 25
incrv = 2

while startv <= stopv:
  print("Loop - start value", startv)
  startv = startv + incrv
