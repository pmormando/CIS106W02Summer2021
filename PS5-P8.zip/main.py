def tution(credithours, discode):
  I = 250
  O = 550
  tuition = discode * credithours
  return tuition

lastname = input("enter last name")
credithours = float(input("enter amount of credit hours"))
discode = input("enter district code (I or O)")

tuition = tuition

print(lastname)
print(tuition)