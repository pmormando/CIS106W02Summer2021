quantityofwidget = int(input("Enter quantity of widget"))

if quantityofwidget > 10000:
  amount = 10
elif quantityofwidget > 5000 or quantityofwidget < 10000:
  amount = 20
else:
  amount = 30

extendedprice = quantityofwidget * amount
tax = extendedprice * 0.07
total = tax + extendedprice

print("extended price", extendedprice)
print("tax", tax)
print("total", total)