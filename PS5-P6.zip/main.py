def compMPG(milestraveled, gallonsused):
  MPG = milestraveled / gallonsused

  return MPG

destinationcity = input("destination city")
milestraveled = float(input("enter miles traveled"))
gallonsused = float(input("enter amount of gallons used"))

MPG = compMPG(milestraveled, gallonsused)

def cost(gallonsused, costpergallon):
  NoG = milestraveled / MPG
  cost = NoG * costpergallon

  return cost

costpergallon = 2.50

costofgas = cost(gallonsused, costpergallon)

print("destination city", destinationcity)
print("miles per gallon", MPG)
print("miles traveled", milestraveled)
print("cost of gas", costofgas)