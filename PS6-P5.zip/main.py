def compute(qty, price, tax):
  total = qty * unitprice
  tax = total * 0.07
  actualtotal = tax + total

  return qty, price

  qty = float(input("quantity"))
  unitprice = float(input("unit price"))

  total, tax, actualtotal = compute(qty, price, tax)

  print("total", actualtotal)
  print("tax", tax)