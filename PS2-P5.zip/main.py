lastname = input("Enter last name")
grosspay = input("Enter your Gross Income")
nodep = input("Enter dependents")

adjgross = float(grosspay) - 12000.00 * float(nodep)

if adjgross > 50000.00:
  tax = adjgross * .20
else:
    tax = adjgross * .10

    if tax < 0:
      tax = 100.00

print (lastname)
print ("Gross Income:        $", grosspay)
print ("Number of Dependents: ", nodep)
print ("Adjusted Gross:      $", adjgross)
print ("Income Tax:          $", tax)

