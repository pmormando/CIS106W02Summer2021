
def comp(dis, am, pr):
  discountedprice = price * disrate
  discountamount = (1 - disrate) * price

  return discountedprice
  return discountamount

price = float(input("enter amount of item"))
disrate = float(input("enter discount rate in decimal form"))
quantity = float(input("enter quantity"))

discountedprice = comp(dis, am, pr)
discountamount = comp(dis, am, pr)


print("price", price)
print("discounted amount", discountamount)
print("discounted price", discountedprice)
print("quantity", quantity)