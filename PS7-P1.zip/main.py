def display(names):
 for name in names:
   #print the name directly
   print(name)
 
def reverse_display(names):
 for name in names:
   #print the name in reverse like below
   print(name[::-1])
 
names=["name1","name2","name3","name4","name5","name6","name7","name8","name9","name10"]
display(names)
reverse_display(names)
