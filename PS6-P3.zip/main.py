def commission(commissiontotal, commissiontarget):
  if sales >= 10000:
    commission = 0.10
  else:
    commission = 0.05

  commissiontotal = sales * commission
  commissiontarget = commissiontotal + 10000

  return commissiontotal, commissiontarget

  salesperson = input("sales persons last name")
  sales = float(input("sales"))

  commissiontotal, commissiontarget = commission (commissiontotal, commissiontarget)

  print("sales persons last name", salesperson)
  print("commission", commission)
  print("next years target", comissiontarget)